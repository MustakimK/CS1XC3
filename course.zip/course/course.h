/**
 * @file course.h
 * @author Mustakim Kazi (kazim18@mcmaster.ca)
 * @brief course.h is used to create the "Course" typedef and predfine the functions used in "cource.c".
 * @version 0.1
 * @date 2022-04-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief A struct for Course which includes the name, code, number of students enrolled, and total students.
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * @brief Predefines the enroll_student function in "course.c"
 * 
 * @param course A pointer to typdef "Course".
 * @param student A pointer to typdef "Student".
 */
void enroll_student(Course *course, Student *student);

/**
 * @brief Predefines the print_course function in "course.c"
 * 
 * @param course A pointer to typdef "Course".
 */
void print_course(Course *course);

/**
 * @brief Predefines the *top_student function in "course.c"
 * 
 * @param course A pointer to typdef "Course".
 * @return Student* Student* student with highest average
 */
Student *top_student(Course* course);

/**
 * @brief Predefines the *passing function in "course.c"
 * 
 * @param course A pointer to typdef "Course".
 * @param total_passing A pointer that points to the array of students passing the course.
 * @return Student* A pointer that points to the array of students passing the course.
 */
Student *passing(Course* course, int *total_passing);


