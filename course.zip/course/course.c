/**
 * @file course.c
 * @author Mustakim Kazi (kazim18@mcmaster.ca)
 * @brief course.c is used to manipulate information of a course such as enrolling students, printing course information, finding the top student and finding the amount of students passing.
 * @version 0.1
 * @date 2022-04-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief Adds a student to a course by adding them to the end of a list.
 * 
 * @param course A pointer to typdef "Course".
 * @param student A pointer to typdef "Student".
 */
void enroll_student(Course *course, Student *student)
{
  //Sets the size of the list with calloc if the list is empty, if the list is not empty it resizes the list using realloc.
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints info about a course
 * 
 * @param course A pointer to typdef "Course"
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name); //Prints course name
  printf("Code: %s\n", course->code); //Prints course code
  printf("Total students: %d\n\n", course->total_students); //Prints total number of students in the course
  printf("****************************************\n\n");

  //A for loop to print all the students in the course.
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Finds the student with the highest grade in the class.
 * 
 * @param course A pointer to typdef "Course"
 * @return Student* student with highest average
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  //For loop to go through all the students in the class and find the top student by comparing the current top student with the next one in the list
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  //Returns the student with the highest grade.
  return student;
}

/**
 * @brief Returns a list of all students that are passing the course (a grade greater or equal to 50%). 
 * 
 * @param course A pointer to typdef "Course"
 * @param total_passing A pointer that points to the array of students passing the course.
 * @return Student* Dynamic array of students passing the course
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //Increments a counter varible called "count" by 1 each time it finds a student passing the course.
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  

  //Sets the size of the dynamic array that was defined on line 93 with the number of students passing the course.
  passing = calloc(count, sizeof(Student));

  //This for loops finds students passing the course and adds them to the dynamic array "passing"
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  //Returns the passing array
  return passing;
}