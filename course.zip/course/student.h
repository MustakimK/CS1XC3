/**
 * @file student.h
 * @author Mustakim Kazi (kazim18@mcmaster.ca)
 * @brief student.h is used to create the "Student" typedef and predfine the functions used in "cource.c".
 * @version 0.1
 * @date 2022-04-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */


/**
 * @brief  A struct for Student which includes the first name, last name, student ID, their grades, and number of grades they have.
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * @brief Predefines the add_grade function in "student.c"
 * 
 * @param student A pointer to typdef "Student".
 * @param grade A variable that stores the students' grade 
 */
void add_grade(Student *student, double grade);

/**
 * @brief Predefines the average function in "student.c"
 * 
 * @param student A pointer to typdef "Student".
 * @return double 
 */
double average(Student *student);

/**
 * @brief Predefines the print_student function in "student.c"
 * 
 * @param student A pointer to typdef "Student".
 */
void print_student(Student *student);

/**
 * @brief Predefines the generate_random_student function in "student.c"
 * 
 * @param grades integer value that represents the number of grades a student has
 * @return Student* 
 */
Student* generate_random_student(int grades); 
